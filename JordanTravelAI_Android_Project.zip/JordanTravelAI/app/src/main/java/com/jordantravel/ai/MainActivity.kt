package com.jordantravel.ai

import android.os.Bundle
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val navy = Color.rgb(11, 31, 51)
    private val gold = Color.rgb(201, 162, 39)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun baseLayout(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 20)
            setBackgroundColor(Color.WHITE)
        }
    }

    private fun title(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 28f
        setTextColor(navy)
        setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(0, 10, 0, 20)
    }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            setBackgroundColor(navy)
            textSize = 16f
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 58
            ).apply { setMargins(0, 7, 0, 7) }
        }

    private fun showHome() {
        val l = baseLayout()
        l.addView(title("Jordan Travel AI 🇯🇴"))
        l.addView(TextView(this).apply {
            text = "Your smart guide to Jordan\nدليلك الذكي لاكتشاف الأردن"
            textSize = 18f
            setTextColor(navy)
            setPadding(0, 0, 0, 18)
        })
        l.addView(button("📍 Explore Jordan") { showPlaces() })
        l.addView(button("📷 Smart Camera") { showInfo("Smart Camera", "Camera module ready for integration.") })
        l.addView(button("💱 Currency Converter") { showCurrency() })
        l.addView(button("🤖 AI Tourist Assistant") { showInfo("AI Assistant", "Connect your AI service here.") })
        l.addView(button("⭐ Top Rated Places") { showPlaces() })
        l.addView(button("🗺️ Map") { showInfo("Map", "Map integration can be connected here.") })
        setContentView(l)
    }

    private fun showPlaces() {
        val l = baseLayout()
        l.addView(title("Explore Jordan"))
        listOf(
            "🏛️ Petra — البتراء",
            "🏜️ Wadi Rum — وادي رم",
            "🌊 Dead Sea — البحر الميت",
            "🏺 Jerash — جرش",
            "🏙️ Amman — عمّان",
            "🌴 Aqaba — العقبة"
        ).forEach { place ->
            l.addView(TextView(this).apply {
                text = place
                textSize = 19f
                setTextColor(navy)
                setPadding(10, 18, 10, 18)
            })
        }
        l.addView(button("← Back") { showHome() })
        setContentView(l)
    }

    private fun showCurrency() {
        val l = baseLayout()
        l.addView(title("Currency Converter"))
        val input = EditText(this).apply {
            hint = "Amount in JOD"
            inputType = 2
        }
        l.addView(input)
        val result = TextView(this).apply {
            text = "Enter an amount and press Convert"
            textSize = 18f
            setPadding(0, 20, 0, 20)
        }
        l.addView(result)
        l.addView(button("Convert") {
            val jod = input.text.toString().toDoubleOrNull() ?: 0.0
            result.text = String.format(
                "JOD %.2f\nUSD %.2f\nKRW %.0f\nJPY %.0f\n\n* Demo rates — connect live rates for production.",
                jod, jod * 1.41, jod * 470.0, jod * 220.0
            )
        })
        l.addView(button("← Back") { showHome() })
        setContentView(l)
    }

    private fun showInfo(header: String, message: String) {
        val l = baseLayout()
        l.addView(title(header))
        l.addView(TextView(this).apply {
            text = message
            textSize = 18f
            setTextColor(navy)
            setPadding(0, 10, 0, 30)
        })
        l.addView(button("← Back") { showHome() })
        setContentView(l)
    }
}
