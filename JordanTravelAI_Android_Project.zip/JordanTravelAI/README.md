# Jordan Travel AI

Android starter project for the Jordan Travel AI tourism application.

Included in this first build:
- Home screen
- Jordan destinations
- Currency converter demo
- Smart Camera entry screen
- AI Assistant entry screen
- Map entry screen
- Arabic/English starter content
- Android permissions for camera and internet

Next production integrations:
- Korean/Japanese localization
- Google Maps or another map provider
- Camera landmark recognition
- OCR price recognition
- Live exchange rates
- AI assistant API
- Ratings/reviews database
- Hotels/restaurants and booking links
- Offline tourist information

Build:
1. Open the project in Android Studio or a compatible cloud Android build environment.
2. Sync Gradle.
3. Build > Generate APK.
